$(document).ready(function(){
    $('.error').hide(); 
    var ph = $('.number').val();
    $('.hai').click(function(){
    alert('hai its working');
    });
        
    });