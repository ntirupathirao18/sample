$(document).ready(function () {

    $('.error').hide();
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
            $(this).toggleClass('open');
            $('b', this).toggleClass("caret caret-up");                
        },
        function() {
            $('.dropdown-menu', this).stop( true, true ).fadeOut("fast");
            $(this).toggleClass('open');
            $('b', this).toggleClass("caret caret-up");                
        });


        $("#empid").keypress(function (e) {
            //if the letter is not digit then display error and don't type anything
            if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
               //display error message
               $('#empid').css('border-color','');
                      return false; 
           }
          });

        $("#submit").click(function(){
           var empid = $('#empid').val();
           var pwd   = $('#password').val();
           if ( empid.length == 0 || pwd.length == 0 )
           {    
               if ( empid.length == 0 ) 
               {
                    $('#empid').css('border-color','red');
               }
               if ( pwd.length == 0 )
               {
                    $('#password').css('border-color','red');
               } 
               $("#myModal").effect( "shake", {times:4}, 1000 );
           }    
           else
            {
                $(location).attr('href', 'user.html');


                    
           }
        });
        $("#reset").click(function(){
            $('#empid').css('border-color','');
            $('#password').css('border-color','');
            //$("#loginform")[0].reset()

               
        });
        $('#close').on('click', function()
        { 
            $('#loginform').find('input:text, input:password, select, textarea').val('');
            $('#loginform').find('input:radio, input:checkbox').prop('checked', false);
            $('#empid').css('border-color','');
            $('#password').css('border-color','');
        });


});